// int check_dup(int grid[4][4], int row, int col, int num);
// int check_row_visible(int grid[4][4], int row, int clues_left, int clues_right);
// int check_row_left(int grid[4][4], int row, int expected_clues);
// int check_row_right(int grid[4][4], int row, int expected_clues);
// int check_col_visible(int grid[4][4], int col, int clues_top, int clues_bottom);
// int check_col_top(int grid[4][4], int col, int expected_clues);
// int check_col_bottom(int grid[4][4], int col, int expected_clues);
#include "skyscrapers.h"
//main function check
int	is_safe(int grid[4][4], int row, int col, int val, int *clues)
{
	if (!check_dup(grid, row, col, val))
		return (0);

	grid[row][col] = val;
	if (col == 3)
	{
		if (!check_row_visible(grid, row, clues[8 + row], clues[12 + row]))
		{
			grid[row][col] = 0;
			return (0);
		}
	}

	if (row == 3)
	{
		if (!check_col_visible(grid, col, clues[col], clues[4 + col]))
		{
			grid[row][col] = 0;
			return (0);
		}
	}
	grid[row][col] = 0;
	return (1);
}




//Function check all rules.
int check_dup(int grid[4][4], int row, int col, int num)
{
	int	i;

	i = 0;
	while (i < 4)
	{
		if (grid[i][col] == num)
			return (0);
		i++;
	}
	i = 0;
	while (i < 4)
	{
		if (grid[row][i] == num)
			return (0);
		i++;
	}
	return (1);
}

int check_row_visible(int grid[4][4], int row, int clues_left, int clues_right)
{
	if (!check_row_left(grid, row, clues_left))
		return (0);
	if (!check_row_right(grid, row, clues_right))
		return (0);
	return (1);
}
int check_col_visible(int grid[4][4], int col, int clues_top, int clues_bottom)
{
	if (!check_col_top(grid, col, clues_top))
		return (0);
	if (!check_col_bottom(grid, col, clues_bottom))
		return (0);
	return (1);
}

int check_row_left(int grid[4][4], int row, int expected_clues)
{
	int col;
	int count;
    int maxheight;

	col = 0;
    count = 0;
    maxheight = 0;
	while (col < 4)
	{
		if (grid[row][col] > maxheight)
		{
			maxheight = grid[row][col];
			count++;
		}
		col++;
	}
	if (count == expected_clues)
		return (1);
	return (0);
}
int check_row_right(int grid[4][4], int row, int expected_clues)
{
	int col;
	int count;
    int maxheight;

	col = 3;
    count = 0;
    maxheight = 0;
	while (col >= 0)
	{
		if (grid[row][col] > maxheight)
		{
			maxheight = grid[row][col];
			count++;
		}
		col--;
	}
	if (count == expected_clues)
		return (1);
	return (0);
}
int check_col_top(int grid[4][4], int col, int expected_clues)
{
	int row;
	int count;
    int maxheight;

	row = 0;
    count = 0;
    maxheight = 0;
	while (row < 4)
	{
		if (grid[row][col] > maxheight)
		{
			maxheight = grid[row][col];
			count++;
		}
		row++;
	}
	if (count == expected_clues)
		return (1);
	return (0);
}
int check_col_bottom(int grid[4][4], int col, int expected_clues)
{
	int row;
	int count;
    int maxheight;

	row = 3;
    count = 0;
    maxheight = 0;
	while (row >= 0)
	{
		if (grid[row][col] > maxheight)
		{
			maxheight = grid[row][col];
			count++;
		}
		row--;
	}
	if (count == expected_clues)
		return (1);
	return (0);
}