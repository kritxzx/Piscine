#include "skyscrapers.h"
int	solve(int grid[4][4], int *clues, int row, int col)
{
    int	num;

	//if row = 4, it's complete.
    if (row == 4)
		return (1);
	//if col = 4, go to the next row.
    if (col == 4)
		return (solve(grid, clues, row + 1, 0));

	num = 1;
	while (num <= 4)
	{
		//check position row and col with rules.
		if (is_safe(grid, row, col, num, clues))
		{
			grid[row][col] = num;
			//this is like the checkpoint 
			if (solve(grid, clues, row, col + 1) == 1)
        		return (1);
			grid[row][col] = 0;
		}
		num++;
	}
	return (0);
}
