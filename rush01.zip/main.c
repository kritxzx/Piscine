#include <unistd.h>
#include "skyscrapers.h"

// int  solve(int grid[4][4], int *clues, int row, int col);
// void print_grid(int grid[4][4]);

int main(int argc, char **argv)
{
    int clues[16];
    int grid[4][4] = {
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0}
    };
    if (argc != 2 || !parse_clues(argv[1], clues))
    {
        write(1, "error to parse\n", 15);
        return (0);
    }
    if (solve(grid, clues, 0, 0) == 1)
        print_grid(grid);
    else
        write(1, "Error to solve\n", 15);
    return (0);
}