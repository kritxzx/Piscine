#include <unistd.h>

int parse_clues(char *str, int *clues)
{
    int i;
    int count;

    i = 0;
    count = 0;
    while (str[i] != '\0')
    {
        if (str[i] >= '1' && str[i] <= '4')
        {
            if (count < 16)
                clues[count] = str[i] - '0';
            count++;
        }
        else if (str[i] != ' ')
            return (0);
        i++;
    }
    return (count == 16);
}

void print_grid(int grid[4][4])
{
    int i;
    int j;
    char c;

    i = 0;
    while (i < 4)
    {
        j = 0;
        while (j < 4)
        {
            //int to str
            c = grid[i][j] + '0';
            //write
            write(1, &c, 1);
            if (j < 3)
                write(1, " ", 1);
            j++;
        }
        write(1, "\n", 1);
        i++;
    }
}