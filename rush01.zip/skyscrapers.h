#ifndef SKYSCRAPERS_H
#define SKYSCRAPERS_H

// รายชื่อฟังก์ชันทั้งหมดในระบบ (Prototypes)
int  solve(int grid[4][4], int *clues, int row, int col);
int  is_safe(int grid[4][4], int row, int col, int val, int *clues);
int  check_dup(int grid[4][4], int row, int col, int num);
int  check_row_visible(int grid[4][4], int row, int clues_left, int clues_right);
int  check_row_left(int grid[4][4], int row, int expected_clues);
int  check_row_right(int grid[4][4], int row, int expected_clues);
int  check_col_visible(int grid[4][4], int col, int clues_top, int clues_bottom);
int  check_col_top(int grid[4][4], int col, int expected_clues);
int  check_col_bottom(int grid[4][4], int col, int expected_clues);
void print_grid(int grid[4][4]);
int parse_clues(char *str, int *clues);

#endif